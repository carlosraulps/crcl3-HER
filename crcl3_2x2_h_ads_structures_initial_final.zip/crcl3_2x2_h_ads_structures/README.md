# Hydrogen Adsorption on Monolayer CrCl₃ (2×2 Supercell)
## Initial and Optimized .vasp Structure Archive

This archive contains standardized `.vasp` POSCAR/CONTCAR structure files for hydrogen adsorption on monolayer $\text{CrCl}_3$ using a $2\times2$ supercell. Both Pure PBE (`no_vdw`) and PBE+D3 Grimme zero-damping (`yes_vdw`) variants are provided across all high-symmetry adsorption sites and the pristine substrate.

All files are directly compatible with molecular visualizers and analysis suites: **VESTA**, **OVITO**, **ASE**, **pymatgen**, and **XCrySDen**.

---

## 1. System Specifications & Computational Parameters

- **Substrate:** Monolayer chromium trichloride ($\text{CrCl}_3$, $R\bar{3}$/BiI$_3$-type honeycomb lattice)
- **Supercell Size:** $2\times2$ expansion ($a = b = 12.0925$ Å, $\alpha = \beta = 90^\circ, \gamma = 120^\circ$)
- **Vacuum Spacing:** $20.00$ Å along $z$ (prevents spurious interlayer interactions)
- **Stoichiometry:**
  - Pristine (Clean): $\text{Cr}_8\text{Cl}_{24}$ (32 atoms)
  - Adsorbed ($S_1, S_2, S_3$): $\text{Cr}_8\text{Cl}_{24}\text{H}_1$ (33 atoms)
- **Hydrogen Coverage:** $\theta = 0.25$ H per primitive unit cell ($d_{\mathrm{H-H}} = 12.09$ Å, isolated adatom limit)
- **DFT Framework:** VASP (PAW-PBE)
- **Plane-Wave Cutoff:** $E_{\mathrm{cut}} = 500\text{ eV}$
- **Brillouin Zone:** $\Gamma$-centered $5\times5\times1$ $k$-mesh
- **Spin Polarization:** $ISPIN = 2$ (ferromagnetic ground state for pristine slab: $8 \times 3\,\mu_B = 24.0\,\mu_B$)
- **Electrostatic Correction:** Dipole corrections enabled along $z$ (`LDIPOL = .TRUE.`, `IDIPOL = 3`)
- **Ionic Convergence:** Maximum residual atomic force $|F_{\max}| < 0.025\text{ eV/Å}$

---

## 2. Adsorption Sites & Structural Characteristics

| Site | Target Atom / Position | Initial $d(\mathrm{H-Target})$ | Relaxed $d(\mathrm{H-Target})$ | Lateral Shift $\Delta r_{xy}$ | Vertical Shift $\Delta z$ | Total Magnetization |
|:---|:---|:---:|:---:|:---:|:---:|:---:|
| **$S_1$ (Top-Cl)** | Top-layer $\text{Cl}_{19}$ ligand | $1.300$ Å | **$1.255 - 1.268$ Å** | $\approx 0.0008$ Å | $+0.077 - +0.079$ Å | **$+25.0\,\mu_B$** (FM coupling) |
| **$S_2$ (Hollow)** | Center of 6-membered Cr ring | $1.600$ Å above Cr | **$1.520 - 1.580$ Å** | $< 0.002$ Å | $-0.020 - -0.080$ Å | **$+25.0\,\mu_B$** (FM coupling) |
| **$S_3$ (Top-Cr)** | Central $\text{Cr}_3$ cation | $1.550$ Å | **$1.544 - 1.546$ Å** | **$0.0000$ Å ($C_{3v}$ locked)** | $+0.140 - +0.195$ Å | **$+23.0\,\mu_B$** (AFM coupling) |
| **Clean** | Pristine slab | — | Fully optimized | — | — | **$+24.0\,\mu_B$** (Pristine ground state) |

### Key Physical & Chemical Observations:
1. **Site $S_1$ (Top-Cl):**
   - Hydrogen forms a strong, directional covalent $\mathrm{H-Cl}$ bond ($d = 1.255$ Å), closely resembling molecular $\mathrm{HCl}$ ($1.27$ Å).
   - The coordinated $\text{Cl}_{19}$ ligand is pulled upward out of the halogen plane toward vacuum by $+0.134$ Å.
   - The underlying $\text{Cr}_3\text{--Cl}_{19}$ coordination bond lengthens from $2.357$ Å to $2.687$ Å (+14.0% bond elongation).
   - Magnetic coupling is ferromagnetic ($M = 25\,\mu_B$), where the unpaired electron adds $+1\,\mu_B$ to the slab.

2. **Site $S_3$ (Top-Cr):**
   - Hydrogen forms an apical $\mathrm{H-Cr}$ chemisorption bond ($d = 1.546$ Å), in excellent agreement with literature values ($1.55$ Å).
   - Local $C_{3v}$ 3-fold symmetry at Wyckoff position $(2/3, 1/3)$ completely prevents in-plane drift ($\Delta r_{xy} \equiv 0.0000$ Å); relaxation is strictly vertical along surface normal $z$.
   - The underlying $\text{Cr}_3$ metal cation puckers upward toward the adsorbate by $+0.199$ Å, while the 3 coordinating top-layer chlorine ligands expand radially outward by $+0.030$ Å.
   - Adsorbate electron spin-pairs antiferromagnetically with the localized Cr $3d^3$ manifold, reducing total magnetization to $M = 23\,\mu_B$ ($-1\,\mu_B$).

---

## 3. Directory Layout & File Inventory

```
crcl3_2x2_h_ads_structures/
├── README.md
│
├── no_vdw/                                               [Pure GGA-PBE Functional]
│   ├── crcl3_2x2_no_vdw_clean_pristine_initial.vasp      (Initial unrelaxed clean 2x2 slab)
│   ├── crcl3_2x2_no_vdw_clean_pristine_optimized.vasp    (DFT-optimized clean 2x2 slab)
│   ├── crcl3_2x2_no_vdw_S1_top_Cl_initial.vasp           (Initial unrelaxed Site 1: top-Cl)
│   ├── crcl3_2x2_no_vdw_S1_top_Cl_optimized.vasp         (DFT-optimized Site 1: top-Cl)
│   ├── crcl3_2x2_no_vdw_S2_hollow_initial.vasp           (Initial unrelaxed Site 2: hollow)
│   ├── crcl3_2x2_no_vdw_S2_hollow_optimized.vasp         (DFT-optimized Site 2: hollow)
│   ├── crcl3_2x2_no_vdw_S3_top_Cr_initial.vasp           (Initial unrelaxed Site 3: top-Cr)
│   └── crcl3_2x2_no_vdw_S3_top_Cr_optimized.vasp         (DFT-optimized Site 3: top-Cr)
│
└── yes_vdw/                                              [PBE + Grimme DFT-D3 Zero Damping]
    ├── crcl3_2x2_yes_vdw_clean_pristine_initial.vasp     (Initial unrelaxed clean 2x2 slab)
    ├── crcl3_2x2_yes_vdw_clean_pristine_optimized.vasp   (DFT-optimized clean 2x2 slab)
    ├── crcl3_2x2_yes_vdw_S1_top_Cl_initial.vasp          (Initial unrelaxed Site 1: top-Cl)
    ├── crcl3_2x2_yes_vdw_S1_top_Cl_optimized.vasp        (DFT-optimized Site 1: top-Cl)
    ├── crcl3_2x2_yes_vdw_S2_hollow_initial.vasp          (Initial unrelaxed Site 2: hollow)
    ├── crcl3_2x2_yes_vdw_S2_hollow_optimized.vasp        (DFT-optimized Site 2: hollow)
    ├── crcl3_2x2_yes_vdw_S3_top_Cr_initial.vasp          (Initial unrelaxed Site 3: top-Cr)
    └── crcl3_2x2_yes_vdw_S3_top_Cr_optimized.vasp        (DFT-optimized Site 3: top-Cr)
```

---

## 4. How to Inspect in VESTA or Python

- **VESTA:**  
  Simply drag and drop any `.vasp` file into VESTA. The lattice vectors, elements (`Cr`, `Cl`, `H`), and direct coordinates will be parsed automatically.
- **Python (ASE):**
  ```python
  from ase.io import read
  atoms = read("crcl3_2x2_yes_vdw_S3_top_Cr_optimized.vasp", format="vasp")
  print(f"Total atoms: {len(atoms)}, Formula: {atoms.get_chemical_formula()}")
  ```
- **Python (pymatgen):**
  ```python
  from pymatgen.core import Structure
  struct = Structure.from_file("crcl3_2x2_no_vdw_S1_top_Cl_optimized.vasp")
  print(struct)
  ```
